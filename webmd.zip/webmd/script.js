document.getElementById('toggleDrawer').addEventListener('click', () => {
  const drawer = document.getElementById('moduleDrawer');
  drawer.classList.toggle('hidden');
});
